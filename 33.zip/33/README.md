# Group 33 Project: Spotify Analysis  
# 1 File Structure

---


The file structure of folder `33/` are as following:
```
$ tree 33
33/
├── Data_preprocessing_EDA.ipynb
├── LSTM.ipynb
├── Linear Regression and Random Forest.ipynb
├── README.md
├── Result and Comparison.ipynb
├── SARIMA.ipynb
├── report
│   ├── figures
│   ├── lineno.sty
│   ├── nicefrac.sty
│   ├── nips_2016.sty
│   ├── refs.bib
│   └── template.tex
└── requirements.txt

```

# 2 Access to the data
If anyone wants to run the code, please set/store the csv file at the root directory of 33(`33/`), and read the csv file directly by using the file name.


# 3 Prepare the Environment

---


In this part, a new environment is needed to be created.

## 3.1 Create and Activate a New Virtual Environment 
Using conda in bash to create a new virtual environment named `g33`.
```
conda create --name g33 python=3.12
conda activate g33
```
## 3.2 Install Dependency From requirements.txt
All the dependency requirements can be found in requirements.txt, use the following command to install the required dependency.
```
pip install -r 33/requirements.txt

```

# 4 Run Jupyter Notebooks

---


In this experiment, four learning methods are selected (Seasonal Autoregressive Integrated Moving Average (SAIMA), Linear Regression, Random Forest, and Long Short-Term Memory (LSTM)).  

## 4.1 Data Analysis
In `33/Data_preprocessing_EDA.ipynb` file, several data analysis methods are applied to deal with raw data, for example: Feature Engineering, Clustering, Data Dimension Reduction, Handling of Outliers, and so on. Following four learning methods are based on the same result of this analysis.  

## 4.2 Learning Method: Seasonal Autoregressive Integrated Moving Average
Open and run `33/SARIMA.ipynb` file to see the precesses of SARIMA model.   

## 4.3 Learning Method: Linear Regression and Random Forest
Open and run `33/Linear Regression and Random Forest.ipynb` file to see the processes of Linear Regression and Random Forest model.  

## 4.4 Learning Method: Long Short-Term Memory
Open and run `33/LSTM.ipynb` file to see the precesses of LSTM model.   

## 4.5 Results and Comparison
Open and run `33/Result and Comparison.ipynb` file to see the analysis and comparisons of performances of different models.

